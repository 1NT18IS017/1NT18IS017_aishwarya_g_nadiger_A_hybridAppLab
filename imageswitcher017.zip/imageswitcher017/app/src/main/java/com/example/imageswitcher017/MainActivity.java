package com.example.imageswitcher017;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    Button bu1,bu2;
    ImageView iv;
    boolean flag;
    int i=0;
    int images[]={R.drawable.dollar,R.drawable.output1,R.drawable.output2};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv=(ImageView) findViewById(R.id.img1);
        bu1=(Button)findViewById(R.id.b1);
        bu2=(Button)findViewById(R.id.b2);
        flag=true;
        bu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(images[i]);
                i++;
                if(i==3)
                    i=0;
            }
        });
        bu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iv.setImageResource(images[i]);
                i--;
                if(i==-1)
                    i=2;
            }
        });
    }
}