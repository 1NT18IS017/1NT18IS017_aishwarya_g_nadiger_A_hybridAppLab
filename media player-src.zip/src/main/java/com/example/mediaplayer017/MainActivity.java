package com.example.mediaplayer017;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int st = 0;
    int sp = 0;
    int ft = 5000;
    int bt = 5000;
    MediaPlayer mediaPlayer, mediaPlayernew;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mediaPlayer = MediaPlayer.create(this, R.raw.vm);
        mediaPlayernew = MediaPlayer.create(this, R.raw.vm);
        TextView songtitle = findViewById(R.id.song1);
        songtitle.setText("steal my girl");

        ImageButton play = findViewById(R.id.bu3);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Playing Song", Toast.LENGTH_SHORT).show();
                mediaPlayer.start();
            }
        });
        ImageButton pause = findViewById(R.id.bu4);
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Pausing Song", Toast.LENGTH_SHORT).show();
                mediaPlayer.pause();
            }
        });

        ImageButton forward = findViewById(R.id.bu5);
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentpos = mediaPlayer.getCurrentPosition();
                if ((currentpos + ft) <= (sp = mediaPlayer.getDuration())) {
                    mediaPlayer.seekTo(currentpos + ft);
                }
            }
        });

        ImageButton backward = findViewById(R.id.bu2);
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentpos = mediaPlayer.getCurrentPosition();
                if ((currentpos - bt) >= 0) {
                    mediaPlayer.seekTo(currentpos - bt);
                }
            }
        });

        ImageButton stop =findViewById(R.id.bu6);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Stopping Song", Toast.LENGTH_SHORT).show();
                mediaPlayer.stop();
                mediaPlayer=mediaPlayernew;
            }
        });

        ImageButton restart =findViewById(R.id.bu1);
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Stopping Song", Toast.LENGTH_SHORT).show();
                mediaPlayer.seekTo(0);
                mediaPlayer.start();
            }
        });
    }
}